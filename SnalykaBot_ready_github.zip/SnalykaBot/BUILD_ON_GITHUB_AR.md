# بناء APK من الهاتف

1. ارفع مجلد المشروع إلى مستودع GitHub.
2. افتح تبويب Actions.
3. اختر Build SnalykaBot APK.
4. اضغط Run workflow.
5. بعد نجاح البناء، افتح نتيجة التشغيل ثم قسم Artifacts.
6. نزّل SnalykaBot-debug-apk.zip واستخرج منه app-debug.apk.

لا تضع Bot Token داخل GitHub أو داخل ملفات المشروع. أدخله داخل التطبيق بعد تثبيت الـAPK.

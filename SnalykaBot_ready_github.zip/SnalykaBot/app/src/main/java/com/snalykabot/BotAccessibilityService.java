package com.snalykabot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.*;
import android.view.accessibility.AccessibilityEvent;

public class BotAccessibilityService extends AccessibilityService {
    public static volatile boolean running=false;
    private static BotAccessibilityService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    public static BotAccessibilityService get(){ return instance; }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) { }
    @Override public void onInterrupt(){ running=false; }
    @Override public void onServiceConnected(){ super.onServiceConnected(); instance=this; }
    @Override public void onDestroy(){ if(instance==this) instance=null; running=false; super.onDestroy(); }

    public void tap(float x,float y){
        Path p=new Path(); p.moveTo(x,y);
        GestureDescription g=new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(p,0,80)).build();
        dispatchGesture(g,null,null);
    }
    public void tapRef(float x,float y){
        float sx=getResources().getDisplayMetrics().widthPixels/598f;
        float sy=getResources().getDisplayMetrics().heightPixels/1280f;
        tap(x*sx,y*sy);
    }
    public void swipe(float x1,float y1,float x2,float y2,long duration){
        Path p=new Path(); p.moveTo(x1,y1); p.lineTo(x2,y2);
        GestureDescription g=new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(p,0,duration)).build();
        dispatchGesture(g,null,null);
    }
}

package com.snalykabot;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.net.Uri;import android.provider.Settings;import android.view.*;import android.widget.*;

public class MainActivity extends Activity {
  EditText token;
  @Override public void onCreate(Bundle b){super.onCreate(b); build();}
  void build(){
    LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(32,40,32,32); box.setBackgroundColor(Color.WHITE);
    TextView title=new TextView(this); title.setText("Snalyka Bot\nTelegram + Android"); title.setTextSize(24); title.setTextColor(Color.BLACK); title.setGravity(Gravity.CENTER); box.addView(title,new LinearLayout.LayoutParams(-1,180));
    TextView info=new TextView(this); info.setText("المهمات المضافة: "+MissionCatalog.ALL.size()+"\nTelegram يتحكم في التشغيل، وAccessibility ينفذ اللمسات داخل اللعبة."); info.setTextSize(16); box.addView(info);
    token=new EditText(this); token.setHint("ضع Bot Token هنا"); token.setSingleLine(true); box.addView(token,new LinearLayout.LayoutParams(-1,70));
    Button save=new Button(this); save.setText("حفظ وتشغيل Telegram"); save.setOnClickListener(v->{getPreferences(0).edit().putString("token",token.getText().toString().trim()).apply(); startBot();}); box.addView(save);
    Button acc=new Button(this); acc.setText("تفعيل Accessibility"); acc.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); box.addView(acc);
    Button stop=new Button(this); stop.setText("إيقاف البوت"); stop.setOnClickListener(v->{BotAccessibilityService.running=false;}); box.addView(stop);
    TextView note=new TextView(this); note.setText("مهم: صور المهمات تحدد المسارات، لكن التنفيذ الفعلي داخل خريطة اللعبة يحتاج معايرة للنقرات/التعرف على الشاشة على جهازك."); note.setTextSize(14); box.addView(note,new LinearLayout.LayoutParams(-1,0,1));
    String t=getPreferences(0).getString("token",""); token.setText(t); setContentView(box);
  }
  void startBot(){ String t=token.getText().toString().trim(); if(t.isEmpty()){Toast.makeText(this,"اكتب Bot Token أولًا",Toast.LENGTH_SHORT).show();return;} Intent i=new Intent(this,TelegramBotService.class); i.putExtra("token",t); if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); Toast.makeText(this,"Telegram شغال",Toast.LENGTH_SHORT).show(); }
}

package com.snalykabot;

import java.util.*;

public class Mission {
    public final String id, name;
    public final List<String> steps;
    public Mission(String id, String name, String... steps) {
        this.id=id; this.name=name; this.steps=Arrays.asList(steps);
    }
}

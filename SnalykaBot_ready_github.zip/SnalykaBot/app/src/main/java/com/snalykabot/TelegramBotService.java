package com.snalykabot;

import android.app.*;
import android.content.*;
import android.os.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;

public class TelegramBotService extends Service {
    private volatile boolean active;
    private Thread worker;
    private long offset=0;
    private String token="";
    private static final int NOTIF_ID=77;

    @Override public void onCreate(){ super.onCreate(); startForegroundCompat(); }
    private void startForegroundCompat(){
        String ch="snalyka_bot";
        if(Build.VERSION.SDK_INT>=26){ NotificationChannel nc=new NotificationChannel(ch,"Snalyka Bot",NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager.class).createNotificationChannel(nc); }
        Notification n=new Notification.Builder(this, Build.VERSION.SDK_INT>=26?ch:null)
            .setContentTitle("Snalyka Bot").setContentText("Telegram control is running").setSmallIcon(android.R.drawable.ic_media_play).build();
        startForeground(NOTIF_ID,n);
    }
    public int onStartCommand(Intent i,int flags,int startId){
        if(i!=null && i.hasExtra("token")) token=i.getStringExtra("token");
        if(token==null || token.trim().isEmpty()) return START_NOT_STICKY;
        if(worker==null || !worker.isAlive()){ active=true; worker=new Thread(this::poll,"TelegramPoll"); worker.start(); }
        return START_STICKY;
    }
    private void poll(){
        while(active){
            try{
                String url="https://api.telegram.org/bot"+token+"/getUpdates?timeout=25&offset="+(offset+1);
                String s=get(url); JSONObject root=new JSONObject(s);
                if(!root.optBoolean("ok")) { Thread.sleep(3000); continue; }
                JSONArray a=root.getJSONArray("result");
                for(int i=0;i<a.length();i++){
                    JSONObject u=a.getJSONObject(i); offset=Math.max(offset,u.getLong("update_id")); handle(u);
                }
            }catch(Exception e){ try{Thread.sleep(3000);}catch(Exception ignored){} }
        }
    }
    private void handle(JSONObject u)throws Exception{
        if(u.has("message")){
            JSONObject m=u.getJSONObject("message"); String chat=m.getJSONObject("chat").getString("id"); String text=m.optString("text","").trim();
            if(text.equals("/start")){ sendMenu(chat); }
            else if(text.equals("/stop")){ BotAccessibilityService.running=false; send(chat,"⏹ تم إيقاف البوت."); }
            else if(text.equals("/status")){ send(chat, BotAccessibilityService.running?"🟢 شغال":"⚪ متوقف"); }
        }
        if(u.has("callback_query")){
            JSONObject c=u.getJSONObject("callback_query"); String chat=c.getJSONObject("message").getJSONObject("chat").getString("id"); String data=c.optString("data","");
            if(data.equals("stop")){ BotAccessibilityService.running=false; send(chat,"⏹ تم الإيقاف."); }
            else if(data.startsWith("m:")){ Mission x=MissionCatalog.get(data.substring(2)); if(x!=null){ send(chat,"▶️ بدأت: "+x.name+"\n\n"+String.join(" → ",x.steps)+"\n\n⚠️ المسار موثق، والتنفيذ اللمسي يحتاج معايرة على شاشة لعبتك."); BotAccessibilityService.running=true; } }
        }
    }
    private void sendMenu(String chat)throws Exception{
        StringBuilder b=new StringBuilder("🎮 مهمات سناليكا\n\nاختار المهمة:");
        JSONArray rows=new JSONArray();
        for(int i=0;i<MissionCatalog.ALL.size();i+=2){ JSONArray row=new JSONArray(); for(int j=i;j<Math.min(i+2,MissionCatalog.ALL.size());j++){ Mission m=MissionCatalog.ALL.get(j); row.put(new JSONObject().put("text",m.name).put("callback_data","m:"+m.id)); } rows.put(row); }
        rows.put(new JSONArray().put(new JSONObject().put("text","⏹ إيقاف").put("callback_data","stop")));
        JSONObject kb=new JSONObject().put("inline_keyboard",rows);
        sendKeyboard(chat,b.toString(),kb);
    }
    private void send(String chat,String text)throws Exception{ api("sendMessage",new JSONObject().put("chat_id",chat).put("text",text)); }
    private void sendKeyboard(String chat,String text,JSONObject kb)throws Exception{ api("sendMessage",new JSONObject().put("chat_id",chat).put("text",text).put("reply_markup",kb)); }
    private void api(String method,JSONObject body)throws Exception{ post("https://api.telegram.org/bot"+token+"/"+method,body.toString()); }
    private static String get(String u)throws Exception{ HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection(); c.setConnectTimeout(10000); c.setReadTimeout(35000); return read(c); }
    private static String post(String u,String body)throws Exception{ HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection(); c.setRequestMethod("POST"); c.setDoOutput(true); c.setConnectTimeout(10000); c.setReadTimeout(15000); c.setRequestProperty("Content-Type","application/json"); try(OutputStream o=c.getOutputStream()){o.write(body.getBytes(StandardCharsets.UTF_8));} return read(c); }
    private static String read(HttpURLConnection c)throws Exception{ InputStream in=c.getResponseCode()<400?c.getInputStream():c.getErrorStream(); ByteArrayOutputStream b=new ByteArrayOutputStream(); byte[] x=new byte[4096]; int n; while((n=in.read(x))!=-1)b.write(x,0,n); return b.toString("UTF-8"); }
    @Override public void onDestroy(){ active=false; if(worker!=null) worker.interrupt(); super.onDestroy(); }
    @Override public android.os.IBinder onBind(Intent i){ return null; }
}
